from django.conf.urls import url
from feedback import views

urlpatterns = [
    url('^$',views.feed,name="feed"),
    url(r'android/',views.Feedview.as_view()),
]