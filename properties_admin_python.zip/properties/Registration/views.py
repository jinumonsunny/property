from django.shortcuts import render
from  django.http import HttpResponse
from login.models import Login
from Registration.models import Registration
from django.db.models import Max


from rest_framework.views import APIView
from Registration.serializer import Registrationserializer
from rest_framework.response import Response

# Create your views here.
def registration(request):
    objlist = Registration.objects.filter(type='seller')
    context = {
        'objval': objlist,
    }

    #return HttpResponse("hello world")


    return render(request,'Registration/viewseller.html',context)
def viewbuyers(request):
    objlist = Registration.objects.filter(type='buyer')
    context = {
        'objval': objlist,
    }


    return render(request,'Registration/viewbuyers.html',context)


def approve_buyers(request,idd):
    obj = Registration.objects.get(u_id=idd)
    obj.status="approve"
    obj.save()
    return viewbuyers(request)
def reject_buyers(request,idd):
    obj = Registration.objects.get(u_id=idd)
    obj.status="reject"
    obj.save()
    return viewbuyers(request)




def approve_seller(request,idd):
   obj = Registration.objects.get(u_id=idd)
   obj.status="approve"
   obj.save()
   return viewseller(request)
def reject_seller(request,idd):
   obj = Registration.objects.get(u_id=idd)
   obj.status="reject"
   obj.save()

   return viewseller(request)

class Regview(APIView):
    def get(self,request):
        s=Registration.objects.all()
        ser=Registrationserializer(s,many=True)
        return Response(ser.data)

    def post(self,request):

            obj=Registration()
            ob=Login()

            obj.type = request.data["type"]
            obj.name = request.data["name"]
            obj.email = request.data["email"]
            obj.address = request.data["address"]
            obj.gender = request.data["gender"]
            obj.mobileno = request.data["mobileno"]
            obj.password = request.data["password"]
            obj.status = 'pending'

            obj.save()

            sid = Registration.objects.all().aggregate(Max('u_id'))
            sidd = list(sid.values())[0]

            ob.uid = sidd + 1
            ob.username = request.data["email"]
            ob.password = request.data["password"]
            ob.type = request.data["type"]
            ob.save()

            return HttpResponse("password")
class Regupdate(APIView):
    def get(self, request):
        s = Registration.objects.all()
        ser = Registrationserializer(s, many=True)
        return Response(ser.data)


    def post(self,request):
        obj =Registration.objects.get(u_id=request.data["u_id"])
        obj.address = request.data["address"]
        obj.mobileno = request.data["mobileno"]
        obj.save()
        return HttpResponse("ok")

