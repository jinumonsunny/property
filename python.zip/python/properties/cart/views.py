from django.shortcuts import render
from django.http import HttpResponse
from cart.models import Cart
import datetime

from rest_framework.views import APIView
from cart.serializer import cartserializer
from rest_framework.response import Response


# Create your views here.
def cart(request):
    objlist = Cart.objects.all()
    context = {
        'objval': objlist,
    }
    # return render(request, 'cart/viewcomplaints.html', context)





class Cartview(APIView):
    def get(self, request):
        s = Cart.objects.all()
        ser = cartserializer(s, many=True)
        return Response(ser.data)

    def post(self, request):
        # ser=Complaintserializer(data=request.data)
        # if ser.is_valid():
        #  ser.save()
        #  return HttpResponse("ok")

        obj = Cart()

        obj.u_id = request.data["u_id"]
        obj.p_id = request.data["p_id"]
        # obj.cid = request.data["cid"]
        # obj.image = request.data["img"]
        obj.price = request.data["price"]
        obj.name = request.data["name"]
        obj.description = request.data["description"]
        obj.date = datetime.datetime.today().date()
        obj.save()
        return HttpResponse("ok")


