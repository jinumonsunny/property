from django.conf.urls import url
from Registration import views

urlpatterns = [
    url('^$', views.registration, name="registration"),
    url('^vi/', views.viewbuyers, name="viewbuyers"),
    url(r'android/', views.Regview.as_view()),
]