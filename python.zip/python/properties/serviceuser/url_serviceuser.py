from django.conf.urls import url
from serviceuser import views

urlpatterns = [
url('^$', views.serviceuser, name="serviceuser"),
    url(r'android/', views.Serviview.as_view()),
]