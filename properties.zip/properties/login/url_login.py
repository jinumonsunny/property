from django.conf.urls import url
from login import views

urlpatterns = [
    url('^$', views.login, name="login"),
    url(r'android/', views.Loginview.as_view()),


]