from django.shortcuts import render
from ads.serializer import adsserializer
from rest_framework.response import Response
from ads.models import Ads
def ads(request):
    objlist=Ads.objects.all()
    context={
        'objval':objlist,
    }
    return render(request,'complaints/viewcomplaints.html',context)

# Create your views here.
