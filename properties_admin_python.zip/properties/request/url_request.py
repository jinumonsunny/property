from django.conf.urls import url
from request import views

urlpatterns = [

]