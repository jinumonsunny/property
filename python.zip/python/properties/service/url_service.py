from django.conf.urls import url
from service import views

urlpatterns = [
url('^$', views.service, name="service"),
    url(r'android/', views.Serview.as_view()),
]