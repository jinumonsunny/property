from django.conf.urls import url
from offer import views

urlpatterns = [
    url('^$', views.offer, name="offer"),
    url(r'android/', views. Offview.as_view()),
]