from django.shortcuts import render
from offer.models import Offer
import datetime


from rest_framework.views import APIView
from offer.serializer import offersserializer
from rest_framework.response import Response
# Create your views here.
def offer(request):

    if request.method == "POST":
        obj = Offer()
        obj.name = request.POST.get("Name")
        obj.description = request.POST.get("Description")
        obj.price = request.POST.get("price")
        obj.on_date=datetime.date.today()
        obj.out_date=datetime.date.today()
        obj.save()
    return render(request, 'offer/addoffers.html')
class Offview(APIView):
    def get(self,request):
        s=Offer.objects.all()
        ser=offersserializer(s,many=True)
        return Response(ser.data)

    def post(self,request):

        #ser=Complaintserializer(data=request.data)
       # if ser.is_valid():
          #  ser.save()
      #  return HttpResponse("ok")

            obj=Offer()
            obj.c_id=request.data["o_id"]
            obj.name = request.data["name"]
            obj.description= request.data["description"]
            obj.on_date= request.data["on_date"]
            obj.out_date = request.data["out_date"]
            obj.price= request.data["price"]
            obj.save()
            return HttpResponse("ok")