from django.shortcuts import render
from django.http import HttpResponse
from complaints.models import Complaint
import datetime



from rest_framework.views import APIView
from complaints.serializer import complaintsserializer
from rest_framework.response import Response


# Create your views here.
def cmp(request):
    objlist=Complaint.objects.all()
    context={
        'objval':objlist,
    }
    return render(request,'complaints/viewcomplaints.html',context)

def reply(request):

    if request.method == "POST":
        obj = Complaint()
        obj.reply = request.POST.get("reply")
        obj.p_id = 12
        obj.u_id = 12
        obj.date = datetime.date.today()
        obj.save()


    return render(request,'complaints/adminreply.html')
class Comview(APIView):
    def get(self,request):
        s=Complaint.objects.all()
        ser=complaintsserializer(s,many=True)
        return Response(ser.data)

    def post(self,request):

        #ser=Complaintserializer(data=request.data)
       # if ser.is_valid():
          #  ser.save()
      #  return HttpResponse("ok")

            obj=Complaint()
            obj.c_id =request.data["c_id"]
            obj.u_id = request.data["u_id"]
            obj.reply = request.data["reply"]
            obj.complaints = request.data["complaints"]
            obj.date = request.data["date"]
            obj.p_id = request.data["p_id"]
            obj.save()
            return HttpResponse("ok")