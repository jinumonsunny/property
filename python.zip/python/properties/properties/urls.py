"""properties URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import url,include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns


urlpatterns = [
    url('^complaint/' ,include('complaints.url_cmp')),
    url('^complaint/rp' ,include('complaints.url_cmp')),
    url('^$', include('login.url_login')),
    url('^login/', include('login.url_login')),
    url('^property/', include('property.url_prp')),
    url('^Registration/', include('Registration.url_reg')),
    url('^service/', include('service.url_service')),
    url('^serviceuser/', include('serviceuser.url_serviceuser')),
    url('^offer/', include('offer.url_offer')),
    url('^ads/', include('ads.url_ads')),
    url('^feedback/', include('feedback.url_feedback')),
     url('^cart/', include('cart.url_cart')),






]
urlpatterns+=staticfiles_urlpatterns()