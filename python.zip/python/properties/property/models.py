# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Property(models.Model):
    p_id = models.AutoField(primary_key=True)
    type = models.CharField(db_column='Type', max_length=10)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=20)  # Field name made lowercase.
    description = models.CharField(db_column='Description', max_length=30)  # Field name made lowercase.
    image = models.CharField(max_length=30)
    location = models.CharField(db_column='Location', max_length=20)  # Field name made lowercase.
    longitude = models.CharField(db_column='Longitude', max_length=20)  # Field name made lowercase.
    lattitude = models.CharField(db_column='Lattitude', max_length=20)  # Field name made lowercase.
    video = models.CharField(max_length=20)
    price = models.IntegerField(db_column='Price')  # Field name made lowercase.
    status = models.CharField(max_length=8)
    uid = models.IntegerField()

    class Meta:
        managed = False
        db_table = 'property'
