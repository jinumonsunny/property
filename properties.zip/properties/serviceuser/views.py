from django.shortcuts import render
from serviceuser.models import Serviceuser


from rest_framework.views import APIView
from serviceuser.serializer import serviceuserserializer
from rest_framework.response import Response
# Create your views here.
def serviceuser(request):
    if request.method == "POST":
        obj = Serviceuser()
        obj.sid = request.POST.get("si")
        obj.name = request.POST.get("Name")
        obj.contact_no = request.POST.get("phone")
        obj.phone_number = request.POST.get("phonenumber")
        obj.email_id = request.POST.get("emailid")
        obj.address= request.POST.get("Address")
        obj.location = request.POST.get("Location")
        obj.save()



    return render(request,'serviceuser/addserviceusers.html')

class Serviview(APIView):
    def get(self,request):
        s=Serviceuser.objects.all()
        ser=serviceuserserializer(s,many=True)
        return Response(ser.data)

    def post(self,request):

        #ser=Complaintserializer(data=request.data)
       # if ser.is_valid():
          #  ser.save()
      #  return HttpResponse("ok")

            obj=Property()
            obj.sid =request.data["sid"]
            obj.name = request.data["name"]
            obj.email_id = request.data["emailid"]
            obj.contact_no = request.data["contact_no"]
            obj.address = request.data["address"]
            obj.location = request.data["location"]


            obj.save()
            return HttpResponse("ok")