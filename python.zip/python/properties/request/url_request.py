from django.conf.urls import url
from request import views

urlpatterns = [
    url('^android/', views.RequestView.as_view()),
]