from django.conf.urls import url
from Registration import views

urlpatterns = [
    url('^$', views.registration, name="registration"),
    url('^vi/', views.viewbuyers, name="viewbuyers"),
    url('^android1/', views.Regupdate.as_view()),
    url('^approve_buyers/(?P<idd>\w+)',views.approve_buyers,name='approve_buyers'),
    url('^reject_buyers/(?P<idd>\w+)', views.reject_buyers, name='reject_buyers'),
    url('^approve_seller/(?P<idd>\w+)', views.approve_seller, name='approve_seller'),
    url('^reject_seller/(?P<idd>\w+)', views.reject_seller, name='reject_seller'),
    url('^android/', views.Regview.as_view()),
]