from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from rest_framework.views import APIView
from request.serializer import requestserializer
from rest_framework.response import Response
from request.models import Request



class RequestView(APIView):
    def get(self, request):
        s = Request.objects.all()
        ser = requestserializer(s,many=True)
        return Response(ser.data)

    def post(self, request):

            obj = Request()


            obj.u_id = request.data["u_id"]
            obj.p_id = request.data["p_id"]
            obj.date = request.data["email"]


            obj.status = "pending"

            obj.save()
            return HttpResponse("u_id")