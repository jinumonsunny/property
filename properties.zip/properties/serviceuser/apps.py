from django.apps import AppConfig


class ServiceuserConfig(AppConfig):
    name = 'serviceuser'
