from rest_framework import serializers
from ads.models import Ads


class adsserializer(serializers.ModelSerializer):
    class Meta:
        model = Ads
        fields = '__all__'