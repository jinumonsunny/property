from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from django.http import HttpResponse
from feedback.models import Feedback
import datetime



from rest_framework.views import APIView
from feedback.serializer import feedbackserializer
from rest_framework.response import Response


# Create your views here.
def feed(request):
    objlist=Feedback.objects.all()
    context={
        'objval':objlist,
    }
    return render(request,'feedback/viewfeedbacknew.html',context)


class Feedview(APIView):
    def get(self,request):
        s=Feedback.objects.all()
        ser=feedbackserializer(s,many=True)
        return Response(ser.data)

    def post(self,request):

        #ser=Complaintserializer(data=request.data)
       # if ser.is_valid():
          #  ser.save()
      #  return HttpResponse("ok")

            obj=Feedback()

            obj.u_id = request.data["u_id"]
            obj.feedbk = request.data["feedbk"]
            obj.date = datetime.datetime.today().date()
            obj.rating = request.data["rating"]
            obj.save()
            return HttpResponse("ok")