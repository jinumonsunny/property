from django.shortcuts import render
from  django.http import HttpResponse
from  property.models import Property


from rest_framework.views import APIView
from property.serializer import propertyserializer
from rest_framework.response import Response
from django.core.files.storage import FileSystemStorage
# Create your views here.
def property(request):
    if request.method == "POST":
        obj = Property()
        obj.type = request.POST.get("aa")
        obj.name = request.POST.get("Name")
        obj.description = request.POST.get("description")

        myfile = request.FILES['filename']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        obj.image = myfile.name

        obj.location = request.POST.get("Location")
        obj.longitude = request.POST.get("Longitude")
        obj.lattitude = request.POST.get("Lattitude")

        myfile1 = request.FILES['filename1']
        fs1 = FileSystemStorage()
        filename1 = fs1.save(myfile1.name, myfile1)
        obj.video = myfile1.name


        obj.price = request.POST.get("price")
        obj.uid = "0"
        obj.save()
        context = {
            'msg': "property added successfully"
        }
        return render(request,'property/Add property.html',context)


    return render(request,'property/Add property.html')


def viewproperty(request):
    objlist = Property.objects.all()
    context = {
        'objval': objlist,
    }
    return render(request,'property/viewproperty.html',context)


class Propview(APIView):
    def get(self,request):
        s=Property.objects.all()
        ser=propertyserializer(s,many=True)
        return Response(ser.data)

    def post(self,request):

        #ser=Complaintserializer(data=request.data)
       # if ser.is_valid():
          #  ser.save()
      #  return HttpResponse("ok")

            obj=Property()
            obj.type = request.data["type"]
            obj.name = request.data["name"]
            obj.description = request.data["description"]
            obj.image = request.data["image"]
            obj.location = request.data["location"]
            obj.longitude = request.data["longitude"]
            obj.lattitude = request.data["lattitude"]

            obj.video = request.data["video"]
            obj.price = request.data["price"]

            obj.status = request.data["status"]
            obj.save()

            return HttpResponse("ok")