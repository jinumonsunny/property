from rest_framework import serializers
from property.models import Property


class propertyserializer(serializers.ModelSerializer):
    class Meta:
        model = Property
        fields = '__all__'