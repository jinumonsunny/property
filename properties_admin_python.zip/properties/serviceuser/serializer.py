from rest_framework import serializers
from serviceuser.models import Serviceuser


class serviceuserserializer(serializers.ModelSerializer):
    class Meta:
        model = Serviceuser
        fields = '__all__'