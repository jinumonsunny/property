from django.shortcuts import render
from ads.serializer import adsserializer
from rest_framework.response import Response
from ads.models import Ads
import datetime
from django.http import HttpResponse

from rest_framework.views import APIView
from ads.serializer import adsserializer
from rest_framework.response import Response
def ads(request):
    if request.method == "POST":
        obj = Ads()
        obj.name = request.POST.get("Name")
        obj.description = request.POST.get("Description")
        obj.on_date = datetime.date.today()
        obj.out_date = datetime.date.today()
        obj.save()
        context = {
            'msg': "Ads added successfully"
        }
        return render(request, 'ads/adminads.html', context)
    return render(request, 'ads/adminads.html')
# Create your views here.
class Adsview(APIView):
    def get(self,request):
        s=Ads.objects.all()
        ser=adsserializer(s,many=True)
        return Response(ser.data)

    def post(self, request):
        # ser=Complaintserializer(data=request.data)
        # if ser.is_valid():
        #  ser.save()
        #  return HttpResponse("ok")

        obj = Ads()
        obj.ads_id = request.data["ads_id"]
        obj.ads_name = request.data["ads_name"]
        obj.description = request.data["description"]
        obj.on_date = request.data["on_date"]
        obj.out_date = request.data["out_date"]

        obj.save()
        return HttpResponse("ok")