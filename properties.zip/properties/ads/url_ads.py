from django.conf.urls import url
from ads import views
urlpatterns=[
    url('^$', views.ads, name="ads"),
]