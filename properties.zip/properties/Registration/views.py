from django.shortcuts import render
from  django.http import HttpResponse
from Registration.models import Registration



from rest_framework.views import APIView
from Registration.serializer import Registrationserializer
from rest_framework.response import Response

# Create your views here.
def registration(request):
    objlist = Registration.objects.filter(type='seller')
    context = {
        'objval': objlist,
    }

    #return HttpResponse("hello world")


    return render(request,'Registration/viewseller.html',context)
def viewbuyers(request):
    objlist = Registration.objects.filter(type='buyer')
    context = {
        'objval': objlist,
    }


    return render(request,'Registration/viewbuyers.html',context)


class Regview(APIView):
    def get(self,request):
        s=Registration.objects.all()
        ser=Registrationserializer(s,many=True)
        return Response(ser.data)

    def post(self,request):

        #ser=Complaintserializer(data=request.data)
       # if ser.is_valid():
          #  ser.save()
      #  return HttpResponse("ok")

            obj=Registration()
           # obj.u_id =request.data["u_id"]
            obj.type = request.data["type"]
            obj.name = request.data["name"]
            obj.email = request.data["email"]
            obj.address = request.data["address"]
            obj.gender = request.data["gender"]
            obj.mobileno = request.data["mobileno"]
            obj.password = request.data["password"]


            obj.save()
            return HttpResponse("ok")