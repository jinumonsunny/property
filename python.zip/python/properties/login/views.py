from django.http import HttpResponse
from django.shortcuts import render
from login.models import Login



from rest_framework.views import APIView
from login.serializer import loginsserializer
from rest_framework.response import Response
# Create your views here.
def login(request):
    if request.method == "POST":
        uname = request.POST.get('myusername')
        passw = request.POST.get('mypassword')
        obj = Login.objects.filter(username=uname, password=passw)

        tp = ""
        for ob in obj:
            tp = ob.type
            uid = ob.u_id
            if tp == "admin":
                request.session["admin"] = uid

                return render(request, 'login/adminhome.html')

        else:
                context = {
                    'msg': "invalid credentioal"
                }
                return render(request, 'login/Admin_login.html', context)

    return render(request, 'login/Admin_login.html')


def logout(request):
    request.session["uid"] = ''
    request.session["mail"] = ''

    return login(request)



class Loginview(APIView):
    def get(self,request):
        s=Login.objects.all()
        ser=loginsserializer(s,many=True)
        return Response(ser.data)

    def post(self,request):

        #ser=Complaintserializer(data=request.data)
       # if ser.is_valid():
          #  ser.save()
      #  return HttpResponse("ok")

            obj=Login()

            #obj.u_id = request.data["u_id"]
            #obj.username = request.data["username"]
            #obj.password = request.data["password"]
            #obj.type = request.data["type"]
            #obj.save()

            s = Login.objects.filter(user_name=request.data["user_name"], password=request.data["password"])
            ser = Loginserializer(s, many=True)
            return Response(ser.data)
            #return HttpResponse("ok")