from django.conf.urls import url
from cart import views

urlpatterns = [
    url('^$',views.cart,name="cart"),
    url(r'android/',views.Cartview.as_view()),
]