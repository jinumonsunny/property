from django.conf.urls import url
from property import views

urlpatterns = [
url('^$', views.property, name="property"),
url('^vp', views.viewproperty, name="viewproperty"),
    url(r'android/', views.Propview.as_view()),
]