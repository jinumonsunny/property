from django.shortcuts import render
from service.models import Service


from rest_framework.views import APIView
from service.serializer import serviceserializer
from rest_framework.response import Response
# Create your views here.
def service(request):


    if request.method == "POST":
        obj = Service()
        obj.name = request.POST.get("name")
        obj.description = request.POST.get("description")
        obj.save()


    return render(request,'service/admin_addservices.html')

class Serview(APIView):
    def get(self,request):
        s=Service.objects.all()
        ser=serviceserializer(s,many=True)
        return Response(ser.data)

    def post(self,request):

        #ser=Complaintserializer(data=request.data)
       # if ser.is_valid():
          #  ser.save()
      #  return HttpResponse("ok")

            obj=Service()
            obj.s_id=request.data["s_id"]
            obj.name = request.data["name"]
            obj.description= request.data["description"]


            obj.save()
            return HttpResponse("ok")