from django.apps import AppConfig


class OfferConfig(AppConfig):
    name = 'offer'
