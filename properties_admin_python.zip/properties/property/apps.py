from django.apps import AppConfig


class PropertyConfig(AppConfig):
    name = 'property'
