from django.conf.urls import url
from complaints import views

urlpatterns = [
    url('^$',views.cmp,name="cmp"),
    url('^rp/', views.reply, name="reply"),
    url(r'android/',views.Comview.as_view()),
]